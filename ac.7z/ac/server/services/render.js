const axios = require('axios');


exports.homeRoutes = (req, res) => {
    // Make a get request to /api/users
    axios.get('http://localhost:3000/api/users')
        .then(function(response){
            res.render('index', { users : response.data });
        })
        .catch(err =>{
            res.send(err);
        })

    
}

exports.add_activity = (req, res) =>{
    res.render('add_activity');
}

exports.login = (req, res) =>{
    res.render('login');
}

exports.registration = (req, res) =>{
    res.render('registration');
}
exports.update_activity = (req, res) =>{
    axios.get('http://localhost:3000/api/users', { params : { id : req.query.id }})
        .then(function(userdata){
            res.render("update_activity", { user : userdata.data})
        })
        .catch(err =>{
            res.send(err);
        })
}