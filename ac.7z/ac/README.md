# Activity Tracker Application
In this project, we are going to create node CRUD application with express and mongodb.

npm install


Then Create config.env file and create PORT and MONGO_URI Variable and specify Value.

npm start
